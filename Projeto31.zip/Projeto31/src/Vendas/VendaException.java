package Vendas;

@SuppressWarnings("serial")
public class VendaException extends Exception{

	public VendaException(String msg){
		super(msg);
	}
}

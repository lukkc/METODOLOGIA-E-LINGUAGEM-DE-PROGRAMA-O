package seguradora;

public class Sinistro {

	private float porcentagemPerca;
	private String data;
	
	
	
	
	public Sinistro(float porcentagemPerca, String data) {
		super();
		this.porcentagemPerca = porcentagemPerca;
		this.data = data;
	}
	
	public float getPorcentagemPerca() {
		return porcentagemPerca;
	}
	public void setPorcentagemPerca(float porcentagemPerca) {
		this.porcentagemPerca = porcentagemPerca;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	
	
}

package br.unipe.java.unidade2.atividade1;

public class Main {
	
	public static void main(String[] args) {
		
		semPromocao();
		System.out.println("");
		System.out.println("");
		comPromocao();
		System.out.println("");
		System.out.println("");
		comPromocao2();
		
	}
	
	
	public static void semPromocao(){
		Produto produto = new Produto(1, "perecivel", 10, 5, false);
		Vendedor vendedor = new Vendedor("Lucas", "casa", 0);
		Venda venda = new Venda();
		
		venda.setProduto(produto);
		venda.setVendedor(vendedor);
		venda.setQuantidadeItens(2);
		venda.calcularValor();
		venda.imprimir();
	}
	
	
	public static void comPromocao(){
		Produto produto = new Produto(1, "perecivel", 100, 80, true);
		Vendedor vendedor = new Vendedor("Lucas", "casa", 0);
		Venda venda = new Venda();
		
		venda.setProduto(produto);
		venda.setVendedor(vendedor);
		venda.setQuantidadeItens(3);
		venda.efetuarDesconto(15);
		venda.calcularValor();
		venda.imprimir();
	}
	
	
	public static void comPromocao2(){
		Produto produto = new Produto(1, "perecivel", 100, 80, true);
		Vendedor vendedor = new Vendedor("Lucas", "casa", 0);
		Venda venda = new Venda();
		
		venda.setProduto(produto);
		venda.setVendedor(vendedor);
		venda.setQuantidadeItens(2);
		venda.efetuarDesconto(30);
		venda.calcularValor();
		venda.imprimir();
	}

}

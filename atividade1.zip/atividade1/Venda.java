package br.unipe.java.unidade2.atividade1;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Venda {

	
	public Produto produto; 
	public Vendedor vendedor;
	public float desconto;
	public int quantidadeItens;
	public float valorTotal;
	
	
	
	public Produto getProduto() {
		return produto;
	}
	
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	
	public Vendedor getVendedor() {
		return vendedor;
	}
	
	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}
	
	public int getQuantidadeItens() {
		return quantidadeItens;
	}
	
	public void setQuantidadeItens(int quantidadeItens) {
		this.quantidadeItens = quantidadeItens;
	}
	
	public void calcularValor(){
		float total;
		
		total = (this.produto.getValorVenda() * this.quantidadeItens) - this.desconto;
		
		
		this.valorTotal = total;
	}
	
	public float calcularComissao(){
		float valorComissao;
		valorComissao = (this.vendedor.getComissao() / 100) * this.valorTotal;
		
		if(this.produto.isPromocao() == "Sim"){
			valorComissao = ((this.vendedor.getComissao() / 2) / 100) * this.valorTotal;
		}
		
		return valorComissao;
	}
	
	public void efetuarDesconto(float porcentagem){
		
		float desconto;
		desconto = ((porcentagem / 100) * this.produto.getValorVenda());
		
		if((produto.getValorVenda() - desconto) <= produto.getValorCusto()){
			desconto = 0;
		}
		
		this.desconto = desconto * this.quantidadeItens;
	}
	
	public void imprimir(){
		NumberFormat formatarFloat = new DecimalFormat("#.##");
		
		System.out.println("Código vendedor: " + vendedor.getCodigo());
		System.out.println("Nome vendedor: " + vendedor.getNome());
		System.out.println("Comissão vendedor: $ " + vendedor.getComissao());
		System.out.println("Quantidade de item: " + quantidadeItens);
		System.out.println("Código produto: " + produto.getCodigo());
		System.out.println("Descrição do produto: " + produto.getDescricao());
		System.out.println("Valor do produto: $ " + produto.getValorVenda());
		System.out.println("Produto em promoção?: " + produto.isPromocao());
		System.out.println("Desconto: " + formatarFloat.format(desconto / quantidadeItens) + "%");
		System.out.println("Valor total: $ " + valorTotal);
	}

	
	
}

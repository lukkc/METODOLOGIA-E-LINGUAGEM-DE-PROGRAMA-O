package br.unipe.java.unidade2.atividade1;

public class Vendedor {
	
	
	public String nome;
	public int codigo;
	public String endereco;
	private float comissao;
	
	
	public Vendedor(String nome, String endereco, int codigo){
		super();
		this.nome = nome;
		this.endereco = endereco;
		this.codigo = codigo;
		
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public float getComissao() {
		return comissao;
	}
	public void setComissao(float comissao) {
		this.comissao = comissao;
	} 
	
	

}
